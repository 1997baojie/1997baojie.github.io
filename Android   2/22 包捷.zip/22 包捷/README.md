# MiClockView

高仿小米时钟，同步手机时间精确到毫秒，支持触摸3D旋转效果，完成布局适配

支持的属性有：时钟背景色、亮色（用于分针、秒针、渐变终止色）、暗色（圆弧、刻度线、时针、渐变起始色）、小时文本的字体大小

代码步骤详见 http://blog.csdn.net/qq_31715429/article/details/54668668

告诉你是怎样一步一步实现的~

![image](https://github.com/MonkeyMushroom/MiClockView/raw/master/1.gif)
